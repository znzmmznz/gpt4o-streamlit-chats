
import streamlit as st
import openai
import tempfile
import os
from config import API_KEY

st.set_page_config(page_title="GPT-4o Voice Chat", layout="wide")
st.title("GPT-4o Voice Chat")

openai.api_key = API_KEY

if "chat" not in st.session_state:
    st.session_state.chat = []

# Ввод текста или аудио
user_input = st.text_input("Ты:", key="input")

st.markdown("Или запиши голосовое сообщение:")
audio_file = st.file_uploader("Записать голос (MP3/WAV)", type=["mp3", "wav"])

if audio_file:
    with tempfile.NamedTemporaryFile(delete=False) as tmp_file:
        tmp_file.write(audio_file.read())
        tmp_path = tmp_file.name

    with st.spinner("Распознаём речь..."):
        transcript = openai.Audio.transcribe("whisper-1", open(tmp_path, "rb"))
        user_input = transcript["text"]
        st.write(f"Ты (распознанное): {user_input}")

if user_input:
    st.session_state.chat.append({"role": "user", "content": user_input})
    with st.spinner("GPT думает..."):
        response = openai.ChatCompletion.create(
            model="gpt-4o",
            messages=[{"role": msg["role"], "content": msg["content"]} for msg in st.session_state.chat]
        )
        answer = response.choices[0].message.content.strip()
        st.session_state.chat.append({"role": "assistant", "content": answer})

        st.audio(openai.Audio.speech(model="tts-1", voice="nova", input=answer).read(), format="audio/mp3")

# Отображение диалога
for msg in st.session_state.chat:
    role = "Ты" if msg["role"] == "user" else "GPT-4o"
    st.markdown(f"**{role}:** {msg['content']}")
